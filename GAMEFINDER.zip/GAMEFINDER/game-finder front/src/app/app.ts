import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { NgFor } from '@angular/common';
import { HttpClient, HttpClientModule } from '@angular/common/http';

@Component({
  selector: 'app-root',
  imports: [FormsModule, NgFor, HttpClientModule],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {

  constructor(private http: HttpClient) {}

  nomeJogo: string = '';
  recomendacao: string = '';

  jogos = [
    { id: "41494", nome: "The Last of Us Part II" },
    { id: "28", nome: "Red Dead Redemption 2" },
    { id: "3498", nome: "Grand Theft Auto V" },
    { id: "3255", nome: "Uncharted 4: A Thief's End" },
    { id: "3328", nome: "The Witcher 3: Wild Hunt" },
    { id: "1970", nome: "Mass Effect: Andromeda" },
    { id: "4911", nome: "Days Gone" }
  ];

  selecionarJogo(jogo: any) {
    this.nomeJogo = jogo.id;
  }

  buscarJogo() {

    if (!this.nomeJogo) {
      this.recomendacao = "Selecione um jogo primeiro";
      return;
    }

    this.http
      .get<any>(`http://localhost:8080/api/games/${this.nomeJogo}/recommendation`)
      .subscribe(res => {
        this.recomendacao = res.recommendation;
      });

  }

}
