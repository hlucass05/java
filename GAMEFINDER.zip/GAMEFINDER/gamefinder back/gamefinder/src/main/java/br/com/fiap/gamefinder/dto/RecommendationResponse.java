package br.com.fiap.gamefinder.dto;

// Resposta formatada que o backend enviará ao Angular
public record RecommendationResponse(
        String gameName,
        double rating,
        String recommendation
) {}