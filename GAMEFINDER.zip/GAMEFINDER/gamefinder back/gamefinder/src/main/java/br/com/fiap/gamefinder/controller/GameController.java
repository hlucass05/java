package br.com.fiap.gamefinder.controller;

import br.com.fiap.gamefinder.dto.RecommendationResponse;
import br.com.fiap.gamefinder.service.GameRecommendationService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/games")
@CrossOrigin(origins = "http://localhost:4200") // Permite a chamada do frontend Angular [cite: 7]
public class GameController {

    private final GameRecommendationService service;

    public GameController(GameRecommendationService service) {
        this.service = service;
    }

    @GetMapping("/{id}/recommendation")
    public ResponseEntity<RecommendationResponse> getRecommendation(@PathVariable String id) {
        RecommendationResponse response = service.evaluateGame(id);
        return ResponseEntity.ok(response);
    }
}