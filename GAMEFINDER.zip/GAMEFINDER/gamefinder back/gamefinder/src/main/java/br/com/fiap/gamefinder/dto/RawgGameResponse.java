package br.com.fiap.gamefinder.dto;

import java.time.LocalDate;

// Mapeia o JSON retornado pela API da RAWG
public record RawgGameResponse(
        String name,
        double rating,
        int ratings_count,
        LocalDate released
) {}