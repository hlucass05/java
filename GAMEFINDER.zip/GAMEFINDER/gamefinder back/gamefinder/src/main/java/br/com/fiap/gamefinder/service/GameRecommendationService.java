package br.com.fiap.gamefinder.service;

import br.com.fiap.gamefinder.client.RawgClient;
import br.com.fiap.gamefinder.dto.RawgGameResponse;
import br.com.fiap.gamefinder.dto.RecommendationResponse;
import org.springframework.stereotype.Service;

import java.time.LocalDate;

@Service
public class GameRecommendationService {

    private final RawgClient rawgClient;

    public GameRecommendationService(RawgClient rawgClient) {
        this.rawgClient = rawgClient;
    }

    public RecommendationResponse evaluateGame(String gameId) {
        RawgGameResponse game = rawgClient.getGameDetails(gameId);

        int currentYear = LocalDate.now().getYear();
        int releaseYear = game.released() != null ? game.released().getYear() : currentYear;
        int gameAge = currentYear - releaseYear;

        String resultMessage = "Jogo não se encaixa nas regras principais.";

        // Aplica as regras de negócio [cite: 10]

        // Regra: Altamente Recomendado [cite: 15]
        // Nota média >= 4.5 [cite: 17], Alta quantidade de avaliações [cite: 18], Lançado nos últimos 10 anos [cite: 19]
        if (game.rating() >= 4.5 && game.ratings_count() > 1000 && gameAge <= 10) {
            resultMessage = "★★ Altamente Recomendado"; // [cite: 14, 15]
        }
        // Regra: Vale a pena [cite: 20]
        // Nota média entre 3.5 e 4.5 [cite: 22], Poucas avaliações [cite: 23], Lançado a mais de 10 anos [cite: 24]
        else if (game.rating() >= 3.5 && game.rating() < 4.5 && game.ratings_count() <= 1000 && gameAge > 10) {
            resultMessage = "Vale a pena"; // [cite: 20]
        }
        // Regra: Melhor ver um filme [cite: 25]
        // Nota menor que 3.5 [cite: 27], Baixa popularidade [cite: 28]
        else if (game.rating() < 3.5 && game.ratings_count() < 500) {
            resultMessage = "Melhor ver um filme"; // [cite: 25]
        }

        // Retorna a recomendação interpretada [cite: 11]
        return new RecommendationResponse(game.name(), game.rating(), resultMessage);
    }
}