package br.com.fiap.gamefinder.client;

import br.com.fiap.gamefinder.dto.RawgGameResponse;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

@Component
public class RawgClient {

    @Value("${rawg.api.base-url}")
    private String baseUrl;

    @Value("${rawg.api.key}")
    private String apiKey;

    private final RestTemplate restTemplate;

    public RawgClient() {
        this.restTemplate = new RestTemplate();
    }

    public RawgGameResponse getGameDetails(String gameIdOrName) { // O método recebe id ou nome [cite: 8]
        // Consulta a API da RAWG [cite: 9]
        String url = String.format("%s/games/%s?key=%s", baseUrl, gameIdOrName, apiKey);
        return restTemplate.getForObject(url, RawgGameResponse.class);
    }
}