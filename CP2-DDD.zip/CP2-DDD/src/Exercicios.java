import java.util.Objects;

public class Exercicios {

    private String tipoExercicio;
    private String pergunta;
    private String resposta;
    private Boolean multiplaEscolha;

    public Exercicios() {
    }

    public Exercicios(String tipoExercicio, String pergunta, String resposta, Boolean multiplaEscolha) {
        this.tipoExercicio = tipoExercicio;
        this.pergunta = pergunta;
        this.resposta = resposta;
        this.multiplaEscolha = multiplaEscolha;
    }

    public String getTipoExercicio() {
        return tipoExercicio;
    }

    public void setTipoExercicio(String tipoExercicio) {
        this.tipoExercicio = tipoExercicio;
    }

    public String getPergunta() {
        return pergunta;
    }

    public void setPergunta(String pergunta) {
        this.pergunta = pergunta;
    }

    public String getResposta() {
        return resposta;
    }

    public void setResposta(String resposta) {
        this.resposta = resposta;
    }

    public Boolean getMultiplaEscolha() {
        return multiplaEscolha;
    }

    public void setMultiplaEscolha(Boolean multiplaEscolha) {
        this.multiplaEscolha = multiplaEscolha;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Exercicios that = (Exercicios) o;
        return Objects.equals(tipoExercicio, that.tipoExercicio) && Objects.equals(pergunta, that.pergunta) && Objects.equals(resposta, that.resposta) && Objects.equals(multiplaEscolha, that.multiplaEscolha);
    }

    @Override
    public int hashCode() {
        return Objects.hash(tipoExercicio, pergunta, resposta, multiplaEscolha);
    }

    @Override
    public String toString() {
        return "Exercicios{" +
                "tipoExercicio='" + tipoExercicio + '\'' +
                ", pergunta='" + pergunta + '\'' +
                ", resposta='" + resposta + '\'' +
                ", multiplaEscolha=" + multiplaEscolha +
                '}';
    }
}
