import java.util.Objects;

public class Usuario {

    private String nome;
    private String curso;
    private int licoes;
    private String XP;

    public Usuario() {
    }

    public Usuario(String nome, String curso, int licoes, String XP) {
        this.nome = nome;
        this.curso = curso;
        this.licoes = licoes;
        this.XP = XP;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCurso() {
        return curso;
    }

    public void setCurso(String curso) {
        this.curso = curso;
    }

    public int getLicoes() {
        return licoes;
    }

    public void setLicoes(int licoes) {
        this.licoes = licoes;
    }

    public String getXP() {
        return XP;
    }

    public void setXP(String XP) {
        this.XP = XP;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Usuario usuario = (Usuario) o;
        return licoes == usuario.licoes && Objects.equals(nome, usuario.nome) && Objects.equals(curso, usuario.curso) && Objects.equals(XP, usuario.XP);
    }

    @Override
    public int hashCode() {
        return Objects.hash(nome, curso, licoes, XP);
    }

    @Override
    public String toString() {
        return "Usuario{" +
                "nome='" + nome + '\'' +
                ", curso='" + curso + '\'' +
                ", licoes=" + licoes +
                ", XP='" + XP + '\'' +
                '}';
    }
}
