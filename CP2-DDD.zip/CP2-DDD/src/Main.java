import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        List<Usuario> usuariosCadastrados = new ArrayList<>();
        List<Exercicios> exerciciosRealizados = new ArrayList<>();

        Usuario usuario1 = new Usuario("Ana", "Inglês", 5, "78%");
        usuariosCadastrados.add(usuario1);

        Curso curso1 = new Curso("Ingês", "Exercícios");

        Exercicios exercicios1 = new Exercicios("Tradução", "Como se diz 'Olá em inglês?", "Hello", Boolean.TRUE);
        exerciciosRealizados.add(exercicios1);

        Exercicios exercicios2 = new Exercicios( "Múltipla Escolha", "Qual a tradução de 'Thank You'?", "1.Desculpe 2.Obrigado 3.Por favor 4.Sim", Boolean.TRUE);
        exerciciosRealizados.add(exercicios2);

        System.out.println(usuario1);
        System.out.println(curso1);
        System.out.println(exercicios1);
        System.out.println(exercicios2);
        System.out.println(exerciciosRealizados);

        List<Exercicios> filtroUsuario = exerciciosRealizados.stream()
                .filter(m->m.getClass().equals("Ana"))
                .toList();
        filtroUsuario.forEach(System.out::println);
    }
}
