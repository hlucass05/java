import java.util.Objects;

public class Curso {

    private String idioma;
    private String licao;

    public Curso() {
    }

    public Curso(String idioma, String licao) {
        this.idioma = idioma;
        this.licao = licao;
    }

    public String getIdioma() {
        return idioma;
    }

    public void setIdioma(String idioma) {
        this.idioma = idioma;
    }

    public String getLicao() {
        return licao;
    }

    public void setLicao(String licao) {
        this.licao = licao;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Curso curso = (Curso) o;
        return Objects.equals(idioma, curso.idioma) && Objects.equals(licao, curso.licao);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idioma, licao);
    }

    @Override
    public String toString() {
        return "Curso{" +
                "idioma='" + idioma + '\'' +
                ", licao='" + licao + '\'' +
                '}';
    }
}
