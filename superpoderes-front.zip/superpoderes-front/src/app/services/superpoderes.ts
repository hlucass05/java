import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { map, Observable } from 'rxjs';
import { Superpoder } from '../models/superpoder';

type SpringDataRestResponse = {
  _embedded?: {
    superpoderes?: Superpoder[];
  };
};

@Injectable({ providedIn: 'root' })
export class SuperpoderesService {
  private apiUrl = 'http://localhost:8080/superpoderes';

  constructor(private http: HttpClient) {}

  listar(): Observable<Superpoder[]> {
    return this.http.get<SpringDataRestResponse>(this.apiUrl).pipe(
      map((res) => res._embedded?.superpoderes ?? [])
    );
  }
}
