import { TestBed } from '@angular/core/testing';

import { Superpoderes } from './superpoderes';

describe('Superpoderes', () => {
  let service: Superpoderes;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(Superpoderes);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
