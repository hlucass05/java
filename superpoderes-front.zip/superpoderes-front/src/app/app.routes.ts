import { Routes } from '@angular/router';
import { Superpoderes } from './pages/superpoderes/superpoderes';

export const routes: Routes = [
  { path: '', component: Superpoderes },
];
