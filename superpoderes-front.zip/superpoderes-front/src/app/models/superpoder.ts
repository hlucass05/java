export interface Superpoder {
  id: number;
  nome: string;
  descricao: string;
}
