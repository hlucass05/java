import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SuperpoderesService } from '../../services/superpoderes';
import { Superpoder } from '../../models/superpoder';

@Component({
  selector: 'app-superpoderes',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './superpoderes.html',
  styleUrl: './superpoderes.css',
})
export class Superpoderes implements OnInit {
  superpoderes: Superpoder[] = [];
  loading = true;
  erro = '';

  constructor(private service: SuperpoderesService) {}

  ngOnInit(): void {
    this.service.listar().subscribe({
      next: (dados) => {
        this.superpoderes = dados;
        this.loading = false;
      },
      error: (e) => {
        this.erro = 'Erro ao carregar os dados da API.';
        this.loading = false;
        console.error(e);
      },
    });
  }
}
