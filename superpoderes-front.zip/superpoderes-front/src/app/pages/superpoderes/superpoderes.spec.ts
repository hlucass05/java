import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Superpoderes } from './superpoderes';

describe('Superpoderes', () => {
  let component: Superpoderes;
  let fixture: ComponentFixture<Superpoderes>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Superpoderes],
    }).compileComponents();

    fixture = TestBed.createComponent(Superpoderes);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
