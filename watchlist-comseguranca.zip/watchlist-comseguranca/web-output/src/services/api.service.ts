import { HttpClient, HttpHeaders } from "@angular/common/http";
import { inject, Injectable } from "@angular/core";
import { Observable, tap } from "rxjs";

export type Movie = {
  id: number;
  title: string;
  whereToWatch: string;
  watched: boolean;
}

type MovieRequest = {
  title: string | null;
  whereToWatch: string | null;
}

type LoginRequest = {
  username: string;
  password: string;
}

type LoginResponse = {
  token: string;
}

@Injectable({providedIn: 'root'})
export class ApiService {
  private http = inject(HttpClient);
  private readonly baseUrl = 'http://localhost:8080';

  // Retorna os headers com o token JWT salvo no localStorage
  private getAuthHeaders(): HttpHeaders {
    const token = localStorage.getItem('token');
    return new HttpHeaders({
      'Authorization': `Bearer ${token}`
    });
  }

  // Faz o login na API e salva o token no localStorage
  login(credentials: LoginRequest): Observable<LoginResponse> {
    return this.http.post<LoginResponse>(`${this.baseUrl}/login`, credentials).pipe(
      tap(response => localStorage.setItem('token', response.token))
    );
  }

  // Remove o token do localStorage (logout)
  logout(): void {
    localStorage.removeItem('token');
  }

  // Verifica se o usuário está autenticado
  isAuthenticated(): boolean {
    return !!localStorage.getItem('token');
  }

  // Envia o token em todas as requisições abaixo
  getMovies(): Observable<Movie[]> {
    return this.http.get<Movie[]>(`${this.baseUrl}/movies`, { headers: this.getAuthHeaders() });
  }

  postMovie(movie: MovieRequest): Observable<Movie> {
    return this.http.post<Movie>(`${this.baseUrl}/movies`, movie, { headers: this.getAuthHeaders() });
  }

  markWatched(id: number): Observable<void> {
    return this.http.patch<void>(`${this.baseUrl}/movies/${id}`, {}, { headers: this.getAuthHeaders() });
  }
}
