import { Component, inject } from '@angular/core';
import { Cardmovie } from '../components/cardmovie/cardmovie';
import { Navbar } from '../components/navbar/navbar';
import { ApiService } from '../../services/api.service';
import { AsyncPipe } from '@angular/common';

@Component({
  selector: 'app-home',
  imports: [Cardmovie, Navbar, AsyncPipe],
  templateUrl: './home.html',
  styleUrl: './home.css',
})
export class Home {
  private apiService = inject(ApiService);
  movies$ = this.apiService.getMovies()
}
