import { Component, inject, signal } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { ApiService } from '../../services/api.service';

@Component({
  selector: 'app-login',
  imports: [ReactiveFormsModule],
  templateUrl: './login.html',
  styleUrl: './login.css',
})
export class Login {
  private apiService = inject(ApiService);
  private router = inject(Router);

  errorMessage = signal<string | null>(null);

  loginForm = new FormGroup({
    username: new FormControl(''),
    password: new FormControl(''),
  });

  onSubmit() {
    const { username, password } = this.loginForm.getRawValue();
    if (!username || !password) {
      this.errorMessage.set('Preencha usuário e senha.');
      return;
    }
    this.apiService.login({ username, password }).subscribe({
      next: () => this.router.navigate(['/home']),
      error: () => this.errorMessage.set('Usuário ou senha inválidos.'),
    });
  }
}
