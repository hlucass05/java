import { Component, inject, model } from '@angular/core';
import { ApiService, Movie } from '../../../services/api.service';

@Component({
  selector: 'app-cardmovie',
  imports: [],
  templateUrl: './cardmovie.html',
  styleUrl: './cardmovie.css',
})
export class Cardmovie {
  private apiService = inject(ApiService);

  movie = model.required<Movie>();

  onMarkWatched() {
    this.apiService.markWatched(this.movie().id).subscribe({
      next: () => this.movie.update(movie => ({ ...movie, watched: true })),
      error: err => console.error('Erro ao marcar como assistido. ' + err.status)
    });
  }
}
