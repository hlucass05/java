import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Cardmovie } from './cardmovie';

describe('Cardmovie', () => {
  let component: Cardmovie;
  let fixture: ComponentFixture<Cardmovie>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Cardmovie]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Cardmovie);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
