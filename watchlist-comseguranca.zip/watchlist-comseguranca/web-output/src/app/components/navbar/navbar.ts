import { Component, inject } from '@angular/core';
import { Router } from '@angular/router';
import { ApiService } from '../../../services/api.service';

@Component({
  selector: 'app-navbar',
  imports: [],
  templateUrl: './navbar.html',
  styleUrl: './navbar.css',
})
export class Navbar {
  private apiService = inject(ApiService);
  private router = inject(Router);

  logout() {
    this.apiService.logout();
    this.router.navigate(['/']);
  }
}
