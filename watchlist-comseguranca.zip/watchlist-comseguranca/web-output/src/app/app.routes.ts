import { Routes } from '@angular/router';
import { Login } from './login/login';
import { Home } from './home/home';
import { New } from './new/new';
import { authGuard } from './guards/auth.guard';

export const routes: Routes = [
  {path: '', component: Login, title: 'WatchList - Login'},
  {path: 'home', component: Home, title: 'WatchList - Home', canActivate: [authGuard]},
  {path: 'new', component: New, title: 'WatchList - New', canActivate: [authGuard]},
];
