import { Component, inject, output, signal } from '@angular/core';
import { Navbar } from "../components/navbar/navbar";
import { FormControl, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { ApiService } from '../../services/api.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-new',
  imports: [Navbar, ReactiveFormsModule],
  templateUrl: './new.html',
  styleUrl: './new.css',
})
export class New {
  private apiService = inject(ApiService);
  private router = inject(Router);
  errorMessage = signal<string | null>(null);

  movieForm = new FormGroup({
    title: new FormControl(''),
    whereToWatch: new FormControl(''),
  });

  onSubmit() {
    this.apiService.postMovie(this.movieForm.getRawValue()).subscribe({
      next: () => this.router.navigate(['/home']),
      error: err => this.errorMessage.set('Erro ao adicionar filme. ' + err.status)
    });
  }
}
