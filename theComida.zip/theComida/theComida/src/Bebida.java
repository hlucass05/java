import java.util.Objects;

public class Bebida extends Cardapio {
    private String tipo;

    public Bebida() {
    }

    public Bebida(String nome, String descricao, double preco, String tipo) {
        super(nome, descricao, preco);
        this.tipo = tipo;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;
        Bebida bebida = (Bebida) o;
        return Objects.equals(tipo, bebida.tipo);
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), tipo);
    }

    @Override
    public String toString() {
        return "Bebida{" +
                "tipo='" + tipo + '\'' +
                "} " + super.toString();
    }
}
