import java.util.ArrayList;
import java.util.Objects;

public class Pedido{
        private String nome1;
        private ArrayList<Cardapio> items = new ArrayList<>();

    public Pedido() {
    }

    public Pedido(ArrayList<Cardapio> items) {
        this.items = items;
    }

    public String getNome1() {
        return nome1;
    }

    public void setNome1(String nome1) {
        this.nome1 = nome1;
    }

    public ArrayList<Cardapio> getItems() {
        return items;
    }

    public void setItems(ArrayList<Cardapio> items) {
        this.items = items;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Pedido pedido = (Pedido) o;
        return Objects.equals(nome1, pedido.nome1) && Objects.equals(items, pedido.items);
    }

    @Override
    public int hashCode() {
        return Objects.hash(nome1, items);
    }

    @Override
    public String toString() {
        return "Pedido{" +
                "nome1='" + nome1 + '\'' +
                ", items=" + items +
                '}';
    }
    public void adicionarItem(Cardapio items){
        adicionarItem(new Cardapio());

    public void removerItem(Cardapio items){
        removerItem(new Cardapio());
        }
    }

}
