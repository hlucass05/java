public class Pedido{
    public class Main {
            public static void main(String[] args) {
                Cardapio inventario = new Cardapio();
                inventario.adicionarItem(new Item("Espada"));
                inventario.adicionarItem(new Item("Escudo"));
                inventario.adicionarItem(new Item("Poção"));

                inventario.listarItens();
                // Saída:
                // Espada
                // Escudo
                // Poção
}
