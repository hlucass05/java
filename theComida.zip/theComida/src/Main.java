public class Main extends Cardapio {
    public static void main(String[] args) {
    Cardapio item1 = new Cardapio("Pizza", "Pizza de catupiry", 12.7 );
        System.out.println(item1);

    Bebida item2 = new Bebida("Coca-Cola", "Refrigerante de Cola", 5.5, "gelada");
        System.out.println(item2);

    PratoPrincipal item3 = new PratoPrincipal("Parmegiana de Frango", "Deliciosa Parmegiana de frango com molho e queijo", 32.5, 20.0);
        System.out.println(item3);

    }
}