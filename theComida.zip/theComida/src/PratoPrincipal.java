import java.util.Objects;

public class PratoPrincipal extends Cardapio{
    private Double tempo_preparo;

    public PratoPrincipal() {
    }

    public PratoPrincipal(String nome, String descricao, double preco, Double tempo_preparo) {
        super(nome, descricao, preco);
        this.tempo_preparo = tempo_preparo;
    }

    public Double getTempo_preparo() {
        return tempo_preparo;
    }

    public void setTempo_preparo(Double tempo_preparo) {
        this.tempo_preparo = tempo_preparo;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;
        PratoPrincipal that = (PratoPrincipal) o;
        return Objects.equals(tempo_preparo, that.tempo_preparo);
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), tempo_preparo);
    }

    @Override
    public String toString() {
        return "PratoPrincipal{" +
                "tempo_preparo=" + tempo_preparo +
                "} " + super.toString();
    }
}
