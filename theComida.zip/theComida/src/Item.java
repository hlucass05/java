public class Item {

    private String nome;
}
