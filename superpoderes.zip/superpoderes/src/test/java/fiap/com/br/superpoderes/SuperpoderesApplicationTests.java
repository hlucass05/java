package fiap.com.br.superpoderes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SuperpoderesApplicationTests {

	@Test
	void contextLoads() {
	}

}
