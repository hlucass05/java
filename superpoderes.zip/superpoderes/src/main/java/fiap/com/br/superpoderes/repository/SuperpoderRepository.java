package fiap.com.br.superpoderes.repository;

import fiap.com.br.superpoderes.model.Superpoder;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

// CERTO:
@RepositoryRestResource(collectionResourceRel = "superpoderes", path = "superpoderes")
public interface SuperpoderRepository extends JpaRepository<Superpoder, Long> {
}