package fiap.com.br.superpoderes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SuperpoderesApplication {

	public static void main(String[] args) {
		SpringApplication.run(SuperpoderesApplication.class, args);
	}

}
