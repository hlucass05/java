import java.util.ArrayList;
import java.util.List;

public class Main {

    public static void main(String[] args) {
        List<Usuario> usuariosCadastrados = new ArrayList<>();
        List<Mensagem> mensagensEnviadas = new ArrayList<>();

        Servidor servidor1 = new Servidor("Fiap",mensagensEnviadas,usuariosCadastrados);

        Usuario usuario1 = new Usuario("Lucas",1303);
        usuariosCadastrados.add(usuario1);

        Mensagem mensagem1 = new Mensagem("Eai, VAI CORINTHIANS", "Lucas", "21:24:06");
        mensagensEnviadas.add(mensagem1);
        System.out.println(servidor1);



        List<Mensagem> filtroAutor = mensagensEnviadas.stream()
                .filter(m->m.getAutor().equals("Lucas"))
                .toList();
        filtroAutor.forEach(System.out::println);
    }
}