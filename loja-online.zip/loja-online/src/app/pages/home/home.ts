import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Product } from '../../models/product';
import { ProductCardComponent } from '../../components/product-card/product-card';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [CommonModule, ProductCardComponent],
  templateUrl: './home.html',
  styleUrl: './home.css'
})
export class HomeComponent {

products: Product[] = [
  {
    id: 1,
    name: 'iPhone 17 Pro Max',
    price: 12.999,
    image: 'https://m.media-amazon.com/images/I/51k0qRQFcuL._AC_SX342_.jpg',
    description: 'O mais poderoso smartphone',
    buttonText: 'Comprar na Apple',
    isNew: true
  },
  {
    id: 2,
    name: 'Comedouro Automático',
    price: 299,
    image: 'https://m.media-amazon.com/images/I/51ansqiUO5L._AC_SX569_.jpg',
    description: 'Automático para gatos',
    buttonText: 'Comprar agora',
    isNew: true
  },
  {
    id: 3,
    name: 'Nike Dunk Retro',
    price: 799,
    image: 'https://img.olx.com.br/images/21/210485717019162.jpg',
    description: '36 ao 40',
    buttonText: 'Escolher tamanho',
    isNew: true
  }
]
};


