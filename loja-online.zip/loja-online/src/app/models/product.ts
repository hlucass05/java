export interface Product {
  id: number;
  name: string;
  price: number;
  image: string;
  description: string;
  buttonText: string;
  isNew: boolean;
}
