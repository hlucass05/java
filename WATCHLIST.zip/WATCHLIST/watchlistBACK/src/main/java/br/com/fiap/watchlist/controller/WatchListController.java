package br.com.fiap.watchlist.controller;

import br.com.fiap.watchlist.model.WatchListItem;
import br.com.fiap.watchlist.repository.WatchListRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/items")
@CrossOrigin(origins = "http://localhost:4200/")
public class WatchListController {

    @Autowired
    private WatchListRepository repository;


    @GetMapping
    public List<WatchListItem> listAll() {
        return repository.findAll();
    }


    @PostMapping
    public WatchListItem addItem(@RequestBody WatchListItem item) {
        return repository.save(item);
    }

    // Funcionalidade: Marcar um item como assistido [cite: 11]
    @PutMapping("/{id}/watch")
    public WatchListItem markAsWatched(@PathVariable Long id) {
        WatchListItem item = repository.findById(id).orElseThrow();
        item.setWatched(true);
        return repository.save(item);
    }
}
