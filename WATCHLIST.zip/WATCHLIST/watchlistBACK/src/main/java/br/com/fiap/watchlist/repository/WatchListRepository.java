package br.com.fiap.watchlist.repository;

import br.com.fiap.watchlist.model.WatchListItem;
import org.springframework.data.jpa.repository.JpaRepository;

public interface WatchListRepository extends JpaRepository<WatchListItem, Long> {
}
