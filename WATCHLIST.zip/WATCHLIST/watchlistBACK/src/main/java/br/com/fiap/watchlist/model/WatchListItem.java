package br.com.fiap.watchlist.model;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data // O Lombok cria os getters e setters para você
public class WatchListItem {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String title;           // Título do filme ou série [cite: 9]
    private String watchLocation;    // Onde assistir (Netflix, Cinema, etc.) [cite: 9]
    private boolean watched;         // Status se já foi assistido [cite: 11]
}
