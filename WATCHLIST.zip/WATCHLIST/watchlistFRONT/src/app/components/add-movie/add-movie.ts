import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Movie } from '../../models/movie';
import { MovieService } from '../../services/movie.service';

@Component({
  selector: 'app-add-movie',
  standalone: true,
  imports: [FormsModule, CommonModule],
  templateUrl: './add-movie.html',
  styleUrls: ['./add-movie.css']
})
export class AddMovieComponent implements OnInit {

  constructor(private movieService: MovieService) {}

  movies: Movie[] = [];

  title: string = '';
  platform: string = '';

  ngOnInit() {
    this.movieService.getMovies().subscribe((data) => {
      this.movies = data;
    });
  }

addMovie() {
  const movie: Movie = {
    title: this.title,
    platform: this.platform,
    watched: false
  };

  this.movieService.addMovie(movie).subscribe((savedMovie) => {
    this.movies.push(savedMovie);
  });

  this.title = '';
  this.platform = '';
}

  markAsWatched(movie: Movie) {
    if (!movie.id) return;

    this.movieService.markAsWatched(movie.id).subscribe(() => {
      movie.watched = true;
    });
  }

}
