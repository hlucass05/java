export interface Movie {

  id?: number;

  title: string;

  platform: string;

  watched: boolean;

}
