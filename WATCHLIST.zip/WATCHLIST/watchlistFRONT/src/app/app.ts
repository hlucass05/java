import { Component } from '@angular/core';
import { AddMovieComponent } from './components/add-movie/add-movie';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [AddMovieComponent],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class AppComponent {

}
