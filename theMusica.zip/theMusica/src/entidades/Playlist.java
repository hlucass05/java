package entidades;

import java.util.Arrays;
import java.util.List;
import java.util.Objects;

public class Playlist {
    //Atributos
    private String nome;
    private List<Midia> midias;

    //Metodos
    public void adicionarMidia(Midia midia){
        midias.add(midia);
    }

     public void removerMidia(Midia midia){
        midias.remove(midia);
    }

    public List<Midia> filtrarPorTipo(String tipo){
        return.midias.stream().filter()
    }

    public void reproduzir(){
        System.out.println("Reproduzindo playlist: " + this.nome);
        for(var midia:midias) {
            midia.reproduzir();
            System.out.println("--------------------");
        }
    }

    public Playlist() {
    }

    public Playlist(String nome, List<Midia> midias) {
        this.nome = nome;
        this.midias = midias;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public List<Midia> getMidias() {
        return midias;
    }

    public void setMidias(List<Midia> midias) {
        this.midias = midias;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Playlist playlist = (Playlist) o;
        return Objects.equals(getNome(), playlist.getNome()) && Objects.equals(getMidias(), playlist.getMidias());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getNome(), getMidias());
    }

    @Override
    public String toString() {
        return "Playlist{" +
                "nome='" + nome + '\'' +
                ", midias=" + midias +
                '}';
    }

    public Void playlistFlter(){
        var playlistA = Arrays.asList();

        playlistA.stream()
                .filter(duracao -> playlistA = 5.00)
                .map()
                .toList()
                .forEach((System.out::println));
    }
}
